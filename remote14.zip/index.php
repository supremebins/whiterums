<?php
echo 'Access Denied<p hidden id="version">14</p>';
?>